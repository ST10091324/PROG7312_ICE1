﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG7312_ICE1
{
    //Repository class which is responosble for storing students in a list
    //The Respository uses generics when adding to the List and when the student items are being retrieved
    //
    public class Repository<T> where T : class
    {
        private List<T> students = new List<T>();

        public void Add(T item)
        {
            students.Add(item);
        }

        public void Remove(T item)
        {
            students.Remove(item);
        }

        public IEnumerable<T> GetAll()
        {
            return students;
        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
